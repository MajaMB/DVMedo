<?php

/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  delport
 */
get_header(); ?>

<!-- project details area start -->
<section class="portfolio-details pb-100 pt-100">
    <div class="container">
        <?php
        if (have_posts()):
            while (have_posts()): the_post();

        ?>
                <?php the_content(); ?>
        <?php
            endwhile;
            wp_reset_query();
        endif;
        ?>
    </div>
</section>
<!-- project details area end -->

<?php get_footer();  ?>