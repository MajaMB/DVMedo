<?php

/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  kindedo
 */
get_header(); ?>

<!-- service details area start -->
<section class="services-details pb-100 pt-100">
   <div class="container">
      <?php
      if (have_posts()):
         while (have_posts()): the_post();

      ?>
            <?php the_content(); ?>
      <?php
         endwhile;
         wp_reset_query();
      endif;
      ?>
   </div>
</section>
<!-- service details area end -->

<?php get_footer();  ?>